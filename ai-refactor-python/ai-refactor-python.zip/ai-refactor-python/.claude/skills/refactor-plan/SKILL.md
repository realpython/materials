---
name: refactor-plan
description: Diagnoses code smells in a Python project and writes a refactoring plan to REFACTOR.md. Use when asked to find code smells or plan a refactoring.
---

# Refactoring Plan

Find the code smells in this project and write a refactoring plan to
`REFACTOR.md` at the project root. A person will check every finding
against the code before any refactoring starts, so report only what you
can point to, with exact file paths and line numbers.

This is a read-only diagnosis. `REFACTOR.md` is the only file you create
or change, because the plan has to be reviewed before any code changes.

## 1. Run the Tools

Run these commands and note every issue they flag:

- `uv run ruff check`
- `uv run radon cc <package>/ -s -nb` (blocks ranked B or worse)
- `uv run mypy`

Tools measure structure but miss intent, so treat their output as a
starting point, not the full diagnosis.

## 2. Read the Code

Read every module in the package. Check each one against the tables in
[references/code-smells.md](references/code-smells.md). Also read
`tests/` to learn which behavior the tests pin down, but don't report
smells in the tests themselves.

For every candidate smell, record the file, the line range, the smell
name, and the refactoring from the tables.

Count repeats. If the same pattern appears in several places, report it
once with the full line range and the number of occurrences.

Plan one refactoring per row, small enough that its diff fits on one
screen. Rows can touch the same lines. Give line numbers from the code
as it is now, and say in the notes when a row builds on an earlier one.

## 3. Sort the Findings

Put every finding into exactly one group:

- **Refactor:** a smell that you can remove by restructuring the code,
  without adding features or changing what the app does for its users.
  If the fix requires editing tests or changing a public interface,
  such as a function signature, a CLI option, a message, or an exit
  code, list it anyway and name what has to change in the notes.
- **Bug:** code that behaves incorrectly. Describe how to trigger it.
  Don't fix bugs here, because fixing a bug changes behavior on
  purpose, which is outside a refactoring. If a test asserts the wrong
  behavior, name the test.

If a finding is both a smell and a bug, list it as a bug.

## 4. Write REFACTOR.md

Copy [assets/REFACTOR-template.md](assets/REFACTOR-template.md) to
`REFACTOR.md` at the project root and fill it in. Replace the example
row and placeholder text with your findings, and keep the section
headings as they are.

Order the refactor rows from the smallest change to the largest, so the
first pass is a quick check that the workflow works.

Keep table cells short: the Code Smell and Refactoring cells hold only
the names from the tables. Put evidence in the Notes list, numbered to
match the table rows.

## 5. Report

Finish with a short summary: how many refactorings you planned and how
many bugs you found. Then stop. Don't start refactoring.
