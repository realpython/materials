# RP To-Do

A command-line to-do app built with Typer. It stores to-dos in a JSON file.

## Commands

- Run tests: `uv run pytest`
- Measure coverage: `uv run coverage run -m pytest && uv run coverage report -m`
- Lint: `uv run ruff check`
- Type check: `uv run mypy`

## Refactoring rules

- Don't change behavior. Same inputs, same outputs.
- Don't touch anything under `tests/`.
- Don't fix anything you weren't asked to. Report it instead.
- One refactoring per turn. Stop when it's done.
- Don't add dependencies. Ask before adding imports.
