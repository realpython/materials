from rptodo import SUCCESS, config


def test_init_app(tmp_path, monkeypatch):
    config_dir = tmp_path / "rptodo"
    monkeypatch.setattr(config, "CONFIG_DIR_PATH", config_dir)
    monkeypatch.setattr(config, "CONFIG_FILE_PATH", config_dir / "config.ini")
    assert config.init_app("todo.json") == SUCCESS
    assert config.CONFIG_FILE_PATH.read_text() == (
        "[General]\ndatabase = todo.json\n\n"
    )
