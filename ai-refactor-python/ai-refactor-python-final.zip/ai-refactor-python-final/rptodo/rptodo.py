"""This module provides the RP To-Do model-controller."""

from pathlib import Path
from typing import List, NamedTuple

from rptodo import DB_READ_ERROR, ID_ERROR, SUCCESS
from rptodo.database import DatabaseHandler, DBResponse, Todo

DEFAULT_PRIORITY = 2


class CurrentTodo(NamedTuple):
    todo: Todo
    error: int


class Todoer:
    def __init__(self, db_path: Path) -> None:
        self._db_handler = DatabaseHandler(db_path)

    def add(
        self, description: List[str], priority: int = DEFAULT_PRIORITY
    ) -> CurrentTodo:
        """Add a new to-do to the database."""
        description_text = " ".join(description)
        if not description_text.endswith("."):
            description_text += "."
        todo: Todo = {
            "Description": description_text,
            "Priority": priority,
            "Done": False,
        }
        read = self._db_handler.read_todos()
        if read.error == DB_READ_ERROR:
            return CurrentTodo(todo, read.error)
        read.todo_list.append(todo)
        write = self._db_handler.write_todos(read.todo_list)
        return CurrentTodo(todo, write.error)

    def get_todo_list(self) -> List[Todo]:
        """Return the current to-do list."""
        read = self._db_handler.read_todos()
        return read.todo_list

    def _read_todo_list(self, todo_id: int) -> DBResponse:
        """Read the to-do list and check that todo_id points into it."""
        read = self._db_handler.read_todos()
        if read.error:
            return read
        try:
            read.todo_list[todo_id - 1]
        except IndexError:
            return DBResponse(read.todo_list, ID_ERROR)
        return read

    def get_todo(self, todo_id: int) -> CurrentTodo:
        """Return a to-do using its id."""
        todo_list, error = self._read_todo_list(todo_id)
        if error:
            return CurrentTodo({}, error)
        return CurrentTodo(todo_list[todo_id - 1], SUCCESS)

    def set_done(self, todo_id: int) -> CurrentTodo:
        """Set a to-do as done."""
        todo_list, error = self._read_todo_list(todo_id)
        if error:
            return CurrentTodo({}, error)
        todo = todo_list[todo_id - 1]
        todo["Done"] = True
        write = self._db_handler.write_todos(todo_list)
        return CurrentTodo(todo, write.error)

    def remove(self, todo_id: int) -> CurrentTodo:
        """Remove a to-do from the database using its id or index."""
        todo_list, error = self._read_todo_list(todo_id)
        if error:
            return CurrentTodo({}, error)
        todo = todo_list.pop(todo_id - 1)
        write = self._db_handler.write_todos(todo_list)
        return CurrentTodo(todo, write.error)

    def remove_all(self) -> CurrentTodo:
        """Remove all to-dos from the database."""
        write = self._db_handler.write_todos([])
        return CurrentTodo({}, write.error)
