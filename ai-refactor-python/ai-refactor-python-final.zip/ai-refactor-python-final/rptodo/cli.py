"""This module provides the RP To-Do CLI."""

from pathlib import Path
from typing import List, NoReturn, Optional

import typer
from rptodo import ERRORS, __app_name__, __version__, config, database, rptodo

app = typer.Typer()

MIN_PRIORITY = 1
MAX_PRIORITY = 3
CELL_PREFIX_WIDTH = len("| ")
PRIORITY_CELL_PREFIX_WIDTH = len("| ()")
COLUMNS = (
    "ID.  ",
    "| Priority  ",
    "| Done  ",
    "| Description  ",
)
HEADERS = "".join(COLUMNS)


def _exit_with_error(message: str) -> NoReturn:
    typer.secho(message, fg=typer.colors.RED)
    raise typer.Exit(1)


@app.command()
def init(
    db_path: str = typer.Option(
        str(database.DEFAULT_DB_FILE_PATH),
        "--db-path",
        "-db",
        prompt="to-do database location?",
    ),
) -> None:
    """Initialize the to-do database."""
    app_init_error = config.init_app(db_path)
    if app_init_error:
        _exit_with_error(
            f'Creating config file failed with "{ERRORS[app_init_error]}"'
        )
    db_init_error = database.init_database(Path(db_path))
    if db_init_error:
        _exit_with_error(
            f'Creating database failed with "{ERRORS[db_init_error]}"'
        )
    typer.secho(f"The to-do database is {db_path}", fg=typer.colors.GREEN)


def get_todoer() -> rptodo.Todoer:
    if not config.CONFIG_FILE_PATH.exists():
        _exit_with_error('Config file not found. Please, run "rptodo init"')
    db_path = config.get_database_path(config.CONFIG_FILE_PATH)
    if not db_path.exists():
        _exit_with_error('Database not found. Please, run "rptodo init"')
    return rptodo.Todoer(db_path)


@app.command()
def add(
    description: List[str] = typer.Argument(...),
    priority: int = typer.Option(
        rptodo.DEFAULT_PRIORITY,
        "--priority",
        "-p",
        min=MIN_PRIORITY,
        max=MAX_PRIORITY,
    ),
) -> None:
    """Add a new to-do with a DESCRIPTION."""
    todoer = get_todoer()
    todo, error = todoer.add(description, priority)
    if error:
        _exit_with_error(f'Adding to-do failed with "{ERRORS[error]}"')
    typer.secho(
        f"""to-do: "{todo["Description"]}" was added """
        f"""with priority: {priority}""",
        fg=typer.colors.GREEN,
    )


def _format_row(todo_id: int, todo: database.Todo) -> str:
    desc, priority, done = todo.values()
    id_padding = len(COLUMNS[0]) - len(str(todo_id))
    priority_padding = (
        len(COLUMNS[1]) - len(str(priority)) - PRIORITY_CELL_PREFIX_WIDTH
    )
    done_padding = len(COLUMNS[2]) - len(str(done)) - CELL_PREFIX_WIDTH
    return (
        f"{todo_id}{id_padding * ' '}"
        f"| ({priority}){priority_padding * ' '}"
        f"| {done}{done_padding * ' '}"
        f"| {desc}"
    )


@app.command(name="list")
def list_all() -> None:
    """List all to-dos."""
    todoer = get_todoer()
    todo_list = todoer.get_todo_list()
    if len(todo_list) == 0:
        typer.secho(
            "There are no tasks in the to-do list yet", fg=typer.colors.RED
        )
        raise typer.Exit()
    typer.secho("\nto-do list:\n", fg=typer.colors.BLUE, bold=True)
    typer.secho(HEADERS, fg=typer.colors.BLUE, bold=True)
    typer.secho("-" * len(HEADERS), fg=typer.colors.BLUE)
    for todo_id, todo in enumerate(todo_list, 1):
        typer.secho(_format_row(todo_id, todo), fg=typer.colors.BLUE)
    typer.secho("-" * len(HEADERS) + "\n", fg=typer.colors.BLUE)


@app.command(name="complete")
def set_done(todo_id: int = typer.Argument(...)) -> None:
    """Complete a to-do by setting it as done using its TODO_ID."""
    todoer = get_todoer()
    todo, error = todoer.set_done(todo_id)
    if error:
        _exit_with_error(
            f'Completing to-do # "{todo_id}" failed with "{ERRORS[error]}"'
        )
    typer.secho(
        f"""to-do # {todo_id} "{todo["Description"]}" completed!""",
        fg=typer.colors.GREEN,
    )


def _remove_todo(todoer: rptodo.Todoer, todo_id: int) -> None:
    todo, error = todoer.remove(todo_id)
    if error:
        _exit_with_error(
            f'Removing to-do # {todo_id} failed with "{ERRORS[error]}"'
        )
    typer.secho(
        f"""to-do # {todo_id}: '{todo["Description"]}' was removed""",
        fg=typer.colors.GREEN,
    )


@app.command()
def remove(
    todo_id: int = typer.Argument(...),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Force deletion without confirmation.",
    ),
) -> None:
    """Remove a to-do using its TODO_ID."""
    todoer = get_todoer()
    if not force:
        todo, error = todoer.get_todo(todo_id)
        if error:
            _exit_with_error("Invalid TODO_ID")
        delete = typer.confirm(
            f"Delete to-do # {todo_id}: {todo['Description']}?"
        )
        if not delete:
            typer.echo("Operation canceled")
            return
    _remove_todo(todoer, todo_id)


@app.command(name="clear")
def remove_all(
    force: bool = typer.Option(
        ...,
        prompt="Delete all to-dos?",
        help="Force deletion without confirmation.",
    ),
) -> None:
    """Remove all to-dos."""
    todoer = get_todoer()
    if force:
        error = todoer.remove_all().error
        if error:
            _exit_with_error(f'Removing to-dos failed with "{ERRORS[error]}"')
        typer.secho("All to-dos were removed", fg=typer.colors.GREEN)
    else:
        typer.echo("Operation canceled")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"{__app_name__} v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        help="Show the application's version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    return
