"""Top-level package for RP To-Do."""

from enum import IntEnum
from typing import Dict

__app_name__ = "rptodo"
__version__ = "0.1.0"


class ErrorCode(IntEnum):
    message: str

    def __new__(cls, value: int, message: str = "") -> "ErrorCode":
        member = int.__new__(cls, value)
        member._value_ = value
        member.message = message
        return member

    SUCCESS = 0
    DIR_ERROR = 1, "config directory error"
    FILE_ERROR = 2, "config file error"
    DB_READ_ERROR = 3, "database read error"
    DB_WRITE_ERROR = 4, "database write error"
    JSON_ERROR = 5  # No message yet. See the bugs in REFACTOR.md.
    ID_ERROR = 6, "to-do id error"


SUCCESS = ErrorCode.SUCCESS
DIR_ERROR = ErrorCode.DIR_ERROR
FILE_ERROR = ErrorCode.FILE_ERROR
DB_READ_ERROR = ErrorCode.DB_READ_ERROR
DB_WRITE_ERROR = ErrorCode.DB_WRITE_ERROR
JSON_ERROR = ErrorCode.JSON_ERROR
ID_ERROR = ErrorCode.ID_ERROR

ERRORS: Dict[int, str] = {code: code.message for code in ErrorCode if code.message}
