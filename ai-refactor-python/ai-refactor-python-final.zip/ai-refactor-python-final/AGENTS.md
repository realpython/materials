# RP To-Do

A command-line to-do app built with Typer. It stores to-dos in a JSON file.

## Commands

- Run tests: `uv run pytest`
- Measure coverage: `uv run coverage run -m pytest && uv run coverage report -m`
- Lint: `uv run ruff check`
- Type check: `uv run mypy`

## Refactoring rules

- Preserve behavior: same inputs, same outputs. The tests define
  what "same" means.
- Leave `tests/` untouched. The tests are the reference for every
  change. The one exception: when you move a function or class to
  another module, move its tests to the matching test file and change
  only the module they call.
- Report anything outside the current refactoring instead of
  fixing it.
- Apply one refactoring per turn. Then run the tests, Ruff, and mypy,
  and fix your change until the tests pass and the checks report
  nothing new. Stop when they do, so I can review the diff.
- If you can't make the checks pass without editing tests or changing
  behavior, stop and explain why.
- Use only the installed packages. Ask before adding any import,
  even from the standard library.
