# RP To-Do

A command-line to-do app built with Typer. It stores to-dos in a JSON file.

## Commands

- Run tests: `uv run pytest`
- Measure coverage: `uv run coverage run -m pytest && uv run coverage report -m`
- Lint: `uv run ruff check`
- Type check: `uv run mypy`

## Refactoring rules

- Preserve behavior: same inputs, same outputs. The tests define
  what "same" means.
- Leave `tests/` untouched. The tests are the reference for every
  change.
- Report anything outside the current refactoring instead of
  fixing it.
- Apply one refactoring per turn, then stop so I can review the diff.
- Use only the installed packages. Ask before adding any import,
  even from the standard library.
