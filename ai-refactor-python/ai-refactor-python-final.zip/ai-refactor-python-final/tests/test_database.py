import json

from rptodo import SUCCESS, database

TODO_LIST = [{"Description": "Get some milk.", "Priority": 2, "Done": False}]


def test_init_database(tmp_path):
    db_path = tmp_path / "todo.json"
    assert database.init_database(db_path) == SUCCESS
    assert db_path.read_text() == "[]"


def test_read_todos(tmp_path):
    db_path = tmp_path / "todo.json"
    db_path.write_text(json.dumps(TODO_LIST))
    handler = database.DatabaseHandler(db_path)
    assert handler.read_todos() == (TODO_LIST, SUCCESS)


def test_write_todos(tmp_path):
    db_path = tmp_path / "todo.json"
    handler = database.DatabaseHandler(db_path)
    assert handler.write_todos(TODO_LIST) == (TODO_LIST, SUCCESS)
    assert json.loads(db_path.read_text()) == TODO_LIST
