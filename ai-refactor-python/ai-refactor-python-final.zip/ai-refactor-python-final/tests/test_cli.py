import json

import pytest
from rptodo import __app_name__, __version__, cli, config
from typer.testing import CliRunner

runner = CliRunner()

TODOS = [
    {"Description": "Get some milk.", "Priority": 2, "Done": False},
    {"Description": "Walk the dog.", "Priority": 1, "Done": True},
]


def write_config(config_file, db_path):
    config_file.write_text(f"[General]\ndatabase = {db_path}\n")


@pytest.fixture
def config_file(tmp_path, monkeypatch):
    config_file = tmp_path / "config.ini"
    monkeypatch.setattr(config, "CONFIG_DIR_PATH", tmp_path)
    monkeypatch.setattr(config, "CONFIG_FILE_PATH", config_file)
    return config_file


@pytest.fixture
def db_file(tmp_path, config_file):
    db_file = tmp_path / "todo.json"
    db_file.write_text(json.dumps(TODOS))
    write_config(config_file, db_file)
    return db_file


@pytest.fixture
def unreadable_db(tmp_path, config_file):
    # A directory exists but can't be read or written as a file.
    db_dir = tmp_path / "todo_dir"
    db_dir.mkdir()
    write_config(config_file, db_dir)
    return db_dir


def read_db(db_file):
    return json.loads(db_file.read_text())


def test_version():
    result = runner.invoke(cli.app, ["--version"])
    assert result.exit_code == 0
    assert f"{__app_name__} v{__version__}\n" in result.stdout


def test_init(tmp_path, monkeypatch):
    config_dir = tmp_path / "rptodo"
    monkeypatch.setattr(config, "CONFIG_DIR_PATH", config_dir)
    monkeypatch.setattr(config, "CONFIG_FILE_PATH", config_dir / "config.ini")
    db_path = tmp_path / "todo.json"
    result = runner.invoke(cli.app, ["init", "--db-path", str(db_path)])
    assert result.exit_code == 0
    assert result.output == f"The to-do database is {db_path}\n"
    assert db_path.read_text() == "[]"
    assert config.CONFIG_FILE_PATH.read_text() == (
        f"[General]\ndatabase = {db_path}\n\n"
    )


def test_init_prompts_for_db_path(tmp_path, monkeypatch):
    config_dir = tmp_path / "rptodo"
    monkeypatch.setattr(config, "CONFIG_DIR_PATH", config_dir)
    monkeypatch.setattr(config, "CONFIG_FILE_PATH", config_dir / "config.ini")
    db_path = tmp_path / "todo.json"
    result = runner.invoke(cli.app, ["init"], input=f"{db_path}\n")
    assert result.exit_code == 0
    assert result.output.endswith(f"The to-do database is {db_path}\n")


def test_init_config_dir_error(tmp_path, monkeypatch):
    config_dir = tmp_path / "missing" / "rptodo"
    monkeypatch.setattr(config, "CONFIG_DIR_PATH", config_dir)
    monkeypatch.setattr(config, "CONFIG_FILE_PATH", config_dir / "config.ini")
    result = runner.invoke(cli.app, ["init", "--db-path", "todo.json"])
    assert result.exit_code == 1
    assert result.output == (
        'Creating config file failed with "config directory error"\n'
    )


def test_init_config_file_error(tmp_path, monkeypatch):
    config_dir = tmp_path / "rptodo"
    config_dir.mkdir()
    config_file = config_dir / "config.ini"
    config_file.mkdir()  # A directory can't be touched as a file.
    monkeypatch.setattr(config, "CONFIG_DIR_PATH", config_dir)
    monkeypatch.setattr(config, "CONFIG_FILE_PATH", config_file)
    result = runner.invoke(cli.app, ["init", "--db-path", "todo.json"])
    assert result.exit_code == 1
    assert result.output == (
        'Creating config file failed with "database write error"\n'
    )


def test_init_database_error(tmp_path, monkeypatch):
    config_dir = tmp_path / "rptodo"
    monkeypatch.setattr(config, "CONFIG_DIR_PATH", config_dir)
    monkeypatch.setattr(config, "CONFIG_FILE_PATH", config_dir / "config.ini")
    db_path = tmp_path / "missing" / "todo.json"
    result = runner.invoke(cli.app, ["init", "--db-path", str(db_path)])
    assert result.exit_code == 1
    assert result.output == (
        'Creating database failed with "database write error"\n'
    )


def test_config_not_found(config_file):
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 1
    assert result.output == 'Config file not found. Please, run "rptodo init"\n'


def test_database_not_found(tmp_path, config_file):
    write_config(config_file, tmp_path / "missing.json")
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 1
    assert result.output == 'Database not found. Please, run "rptodo init"\n'


def test_config_without_general_section(config_file):
    config_file.write_text("")
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 1
    assert isinstance(result.exception, KeyError)


@pytest.mark.parametrize(
    "args, output, priority",
    [
        (
            ["add", "Buy", "bread"],
            'to-do: "Buy bread." was added with priority: 2\n',
            2,
        ),
        (
            ["add", "Buy bread.", "-p", "1"],
            'to-do: "Buy bread." was added with priority: 1\n',
            1,
        ),
        (
            ["add", "Buy bread", "--priority", "3"],
            'to-do: "Buy bread." was added with priority: 3\n',
            3,
        ),
    ],
)
def test_add(db_file, args, output, priority):
    result = runner.invoke(cli.app, args)
    assert result.exit_code == 0
    assert result.output == output
    assert read_db(db_file)[-1] == {
        "Description": "Buy bread.",
        "Priority": priority,
        "Done": False,
    }


@pytest.mark.parametrize("priority", ["0", "4"])
def test_add_priority_out_of_range(db_file, priority):
    result = runner.invoke(cli.app, ["add", "Buy bread", "-p", priority])
    assert result.exit_code == 2
    assert "Invalid value" in result.output
    assert read_db(db_file) == TODOS


def test_add_read_error(unreadable_db):
    result = runner.invoke(cli.app, ["add", "Buy bread"])
    assert result.exit_code == 1
    assert result.output == (
        'Adding to-do failed with "database read error"\n'
    )


def test_add_malformed_json(db_file):
    db_file.write_text("[{")
    result = runner.invoke(cli.app, ["add", "Buy bread"])
    assert result.exit_code == 0
    assert read_db(db_file) == [
        {"Description": "Buy bread.", "Priority": 2, "Done": False}
    ]


def test_list(db_file):
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 0
    assert result.output == (
        "\nto-do list:\n\n"
        "ID.  | Priority  | Done  | Description  \n"
        "----------------------------------------\n"
        "1    | (2)       | False | Get some milk.\n"
        "2    | (1)       | True  | Walk the dog.\n"
        "----------------------------------------\n\n"
    )


def test_list_ten_or_more(db_file):
    todos = [
        {"Description": f"Task {n}.", "Priority": 3, "Done": False}
        for n in range(1, 11)
    ]
    db_file.write_text(json.dumps(todos))
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 0
    assert "9    | (3)       | False | Task 9.\n" in result.output
    assert "10   | (3)       | False | Task 10.\n" in result.output


def test_list_uses_json_key_order(db_file):
    db_file.write_text(
        json.dumps([{"Done": False, "Priority": 2, "Description": "Odd."}])
    )
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 0
    assert "1    | (2)       | Odd.  | False\n" in result.output


@pytest.mark.parametrize("content", ["[]", "[{"])
def test_list_empty(db_file, content):
    db_file.write_text(content)
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 0
    assert result.output == "There are no tasks in the to-do list yet\n"


def test_list_unreadable(unreadable_db):
    result = runner.invoke(cli.app, ["list"])
    assert result.exit_code == 0
    assert result.output == "There are no tasks in the to-do list yet\n"


@pytest.mark.parametrize(
    "todo_id, description",
    [
        ("1", "Get some milk."),
        ("0", "Walk the dog."),
    ],
)
def test_complete(db_file, todo_id, description):
    result = runner.invoke(cli.app, ["complete", todo_id])
    assert result.exit_code == 0
    assert result.output == (
        f'to-do # {todo_id} "{description}" completed!\n'
    )


def test_complete_marks_done(db_file):
    runner.invoke(cli.app, ["complete", "1"])
    assert read_db(db_file)[0]["Done"] is True


def test_complete_invalid_id(db_file):
    result = runner.invoke(cli.app, ["complete", "3"])
    assert result.exit_code == 1
    assert result.output == (
        'Completing to-do # "3" failed with "to-do id error"\n'
    )


def test_complete_read_error(unreadable_db):
    result = runner.invoke(cli.app, ["complete", "1"])
    assert result.exit_code == 1
    assert result.output == (
        'Completing to-do # "1" failed with "database read error"\n'
    )


@pytest.mark.parametrize(
    "args", [["complete", "1"], ["remove", "1", "--force"]]
)
def test_malformed_json_crashes(db_file, args):
    db_file.write_text("{")
    result = runner.invoke(cli.app, args)
    assert result.exit_code == 1
    assert isinstance(result.exception, KeyError)


@pytest.mark.parametrize("flag", ["--force", "-f"])
def test_remove_force(db_file, flag):
    result = runner.invoke(cli.app, ["remove", "1", flag])
    assert result.exit_code == 0
    assert result.output == "to-do # 1: 'Get some milk.' was removed\n"
    assert read_db(db_file) == TODOS[1:]


def test_remove_confirmed(db_file):
    result = runner.invoke(cli.app, ["remove", "2"], input="y\n")
    assert result.exit_code == 0
    assert result.output == (
        "Delete to-do # 2: Walk the dog.? [y/N]: y\n"
        "to-do # 2: 'Walk the dog.' was removed\n"
    )
    assert read_db(db_file) == TODOS[:1]


def test_remove_canceled(db_file):
    result = runner.invoke(cli.app, ["remove", "1"], input="n\n")
    assert result.exit_code == 0
    assert result.output == (
        "Delete to-do # 1: Get some milk.? [y/N]: n\nOperation canceled\n"
    )
    assert read_db(db_file) == TODOS


def test_remove_zero(db_file):
    result = runner.invoke(cli.app, ["remove", "0", "--force"])
    assert result.exit_code == 0
    assert result.output == "to-do # 0: 'Walk the dog.' was removed\n"


def test_remove_invalid_id(db_file):
    result = runner.invoke(cli.app, ["remove", "3"])
    assert result.exit_code == 1
    assert result.output == "Invalid TODO_ID\n"


def test_remove_force_invalid_id(db_file):
    result = runner.invoke(cli.app, ["remove", "3", "--force"])
    assert result.exit_code == 1
    assert result.output == (
        'Removing to-do # 3 failed with "to-do id error"\n'
    )


def test_remove_read_error(unreadable_db):
    result = runner.invoke(cli.app, ["remove", "1", "--force"])
    assert result.exit_code == 1
    assert result.output == (
        'Removing to-do # 1 failed with "database read error"\n'
    )


def test_clear(db_file):
    result = runner.invoke(cli.app, ["clear"], input="y\n")
    assert result.exit_code == 0
    assert result.output == (
        "Delete all to-dos? [y/n]: y\nAll to-dos were removed\n"
    )
    assert read_db(db_file) == []


def test_clear_force(db_file):
    result = runner.invoke(cli.app, ["clear", "--force"])
    assert result.exit_code == 0
    assert result.output == "All to-dos were removed\n"


def test_clear_canceled(db_file):
    result = runner.invoke(cli.app, ["clear"], input="n\n")
    assert result.exit_code == 0
    assert result.output == "Delete all to-dos? [y/n]: n\nOperation canceled\n"
    assert read_db(db_file) == TODOS


def test_clear_write_error(unreadable_db):
    result = runner.invoke(cli.app, ["clear", "--force"])
    assert result.exit_code == 1
    assert result.output == (
        'Removing to-dos failed with "database write error"\n'
    )
