# Refactoring Plan

| # | File | Lines | Code Smell | Refactoring |
| - | ---- | ----- | ---------- | ----------- |
| 1 | package/module.py | 10-24 | Long function | Extract function |

## Notes

1. Evidence for row 1: what the code does now, where exactly, and what
   the refactoring changes. Say whether the tests cover it, and name any
   test or public interface that has to change.

## Bugs Found (Don't Fix Here)

- **One-line summary of the bug.** Where it happens, with file paths and
  line numbers. To trigger: the exact steps or command that reproduce it.
  If a test asserts the wrong behavior, name the test.
