# Refactoring Plan

Line numbers refer to the code before any refactoring. Once earlier rows are applied, find the code by name.

| # | File | Lines | Code Smell | Refactoring |
| - | ---- | ----- | ---------- | ----------- |
| 1 | `rptodo/config.py` | 18-21 | Over-defensive guards | Remove redundant guard |
| 2 | `rptodo/cli.py` | 100-106 | Unclear naming | Rename |
| 3 | `rptodo/config.py` | 18, 36-44 | Unclear naming | Rename |
| 4 | `rptodo/rptodo.py` | 19 | Magic numbers | Replace with named constant |
| 5 | `rptodo/cli.py` | 62 | Magic numbers | Replace with named constant |
| 6 | `rptodo/cli.py` | 103-105 | Magic numbers | Replace with named constant |
| 7 | `rptodo/cli.py` | 36-194 | Nested conditionals | Replace with guard clauses |
| 8 | `rptodo/cli.py` | 24-192 | Copy-paste block | Extract function |
| 9 | `rptodo/rptodo.py` | 43-49, 56-62 | Duplicated code | Extract function |
| 10 | `rptodo/cli.py` | 131-172 | Nested conditionals | Replace with guard clauses |
| 11 | `rptodo/cli.py` | 160-165 | Feature envy | Move function |
| 12 | `rptodo/cli.py` | 81-109 | Long function | Extract function |
| 13 | `rptodo/database.py` | 15-19 | Modular mirage | Move function |
| 14 | `rptodo/__init__.py` | 6-22 | Primitive obsession | Replace primitive with object |
| 15 | `rptodo/rptodo.py` | 11, 24-28 | Primitive obsession | Replace primitive with object |
| 16 | `rptodo/cli.py` | 74, 101, 125, 153, 167 | Primitive obsession | Replace primitive with object |

## Notes

1. `init_app()` checks `database_code != SUCCESS`, returns it, and otherwise returns `SUCCESS`, so both branches return `database_code`. Replace lines 18-21 with `return _create_database(db_path)`. Return values stay the same, and `tests/test_config.py` still covers it.
2. The loop variable `id` (line 100) shadows the built-in `id()`. Rename it to something like `todo_id` or `position`. It's a local name, so output doesn't change.
3. `_create_database()` doesn't create the database. It writes the `[General] database = ...` entry to `config.ini`. The database file is created later by `database.init_database()` in `cli.init`. Rename it to something like `_write_config()` and update the call on line 18. It's private and no test calls it directly.
4. The default priority `2` appears in two files: as the `Todoer.add()` default here (line 19) and as the CLI option default in `cli.py` (row 5). Define a `DEFAULT_PRIORITY` constant in `rptodo.py` and use it as the `Todoer.add()` default. Values don't change, so behavior stays the same.
5. The `--priority` option repeats the default `2` and uses the unnamed bounds `min=1, max=3` (line 62). Use `DEFAULT_PRIORITY` from row 4 as the default, and name the bounds as constants. Values don't change, so behavior stays the same. Builds on row 4.
6. The column padding in `list_all()` subtracts unexplained `4` (the width of `"| ("` plus `")"`) and `2` (the width of `"| "`). Name these widths, or derive them from the format strings, so the padding math explains itself. Output must match character for character.
7. Seven `else:` blocks follow a branch that already ends in `raise typer.Exit(...)`: lines 36, 43, 51, 72, 123, 151, and 193. `get_todoer()` (40-56) is the clearest case, since its happy path sits inside `else` branches. Turn each failure branch into a guard clause and dedent the success path. Control flow and exit codes stay the same.
8. The pattern `typer.secho(<message>, fg=typer.colors.RED)` followed by `raise typer.Exit(1)` repeats 9 times: lines 24-28, 31-35, 44-48, 52-56, 68-71, 118-122, 146-150, 164-165, and 188-192. Extract a helper such as `_fail(message: str) -> NoReturn`. Messages, colors, and exit code 1 stay the same. Do this after row 7, or together with it, so the guards become one-liners.
9. `set_done()` and `remove()` repeat the same steps: read the todos, return the read error, index `todo_list[todo_id - 1]`, and map `IndexError` to `ID_ERROR`. Extract a private helper that reads the list and resolves the index (the only difference is `[]` versus `.pop()`). Keep the current index arithmetic, including how it handles 0 and negative IDs (see Bugs), so behavior doesn't change. `tests/test_rptodo.py::test_set_done` and `::test_remove` pin the results.
10. `remove()` is the only function that ruff flags (C901, complexity 6 > 5). It defines a nested `_remove()` closure and nests the confirm prompt inside `if force ... else`. Move `_remove` to a module-level helper that takes `todoer` and `todo_id`. Then use guard clauses: when not forced, look up the to-do, prompt, and on "no" echo "Operation canceled" and return early. Messages and exit codes stay the same. Builds on row 8.
11. `cli.remove()` reaches into `todoer.get_todo_list()` and indexes it with `todo_id - 1` itself (lines 160-165), which repeats the lookup rule that belongs to `Todoer`. Move the lookup into a `Todoer.get_todo()` method (built on the helper from row 9) and call that from the CLI. The "Invalid TODO_ID" message and exit code 1 stay the same. Builds on rows 9 and 10.
12. `list_all()` handles the empty-list check, the header layout, and per-row padding math in one function. Extract the header and row formatting (lines 91-108) into helpers such as `_format_row()`. Output must stay byte-for-byte the same, which `tests/test_cli.py::test_list` checks. Builds on rows 2 and 6.
13. `database.get_database_path()` only parses `config.ini` with `configparser`, and its only caller passes `config.CONFIG_FILE_PATH` (`cli.py:42`). `config.py` already owns the `[General]` section format (line 38). Move the function to `config.py`. This changes a public interface: `tests/test_database.py::test_get_database_path` calls `database.get_database_path`, so either that test has to move or `database` has to keep re-exporting the name.
14. Error codes are bare ints from `range(7)`, and the messages live in a separate `ERRORS` dict keyed by those ints. That split is how `JSON_ERROR` ended up without a message (see Bugs). Replace them with an `IntEnum` that carries its message. `IntEnum` members compare equal to ints, so `CurrentTodo`/`DBResponse` equality in the tests still holds. Keep the existing module-level names as aliases so imports in `tests/` don't change.
15. A to-do is a `Dict[str, Any]` with the string keys `"Description"`, `"Priority"`, and `"Done"`, typed in `CurrentTodo.todo` (line 11) and built in `add()` (lines 24-28). Introduce a `Todo` `TypedDict` that names the three keys and their types, and use it wherever the code handles to-dos. At runtime, a `Todo` is still a plain dict, so the on-disk JSON stays identical and the tests in `tests/test_rptodo.py` that compare results to plain dicts keep passing. `set_done()` and `remove()` return `{}` on errors, so declare the `TypedDict` with `total=False`. A dataclass would remove more of the smell, but it changes what `CurrentTodo.todo` holds, so it would require editing those tests.
16. The CLI reads to-dos by key at lines 74, 125, 153, and 167. Type the CLI code that handles to-dos with the `Todo` from row 15 so that mypy checks the key names and value types. Line 101 unpacks `todo.values()`, so it depends on the key order in the JSON file. Reading the values by key there would change the output for files with a different key order, so leave it as is. Builds on row 15.

## Bugs Found (Don't Fix Here)

- **`JSON_ERROR` has no message, so the CLI crashes with `KeyError`.** `ERRORS` in `rptodo/__init__.py:16-22` has no entry for `JSON_ERROR`. When the database holds malformed JSON, `read_todos()` returns `JSON_ERROR` (`database.py:46`), and `set_done()`/`remove()` pass it on (`rptodo.py:44-45`, `57-58`). `ERRORS[error]` in `cli.py:119` or `147` then raises a `KeyError` traceback instead of a red message. To trigger: write `{` into the database file, then run `rptodo complete 1` or `rptodo remove 1 --force`.
- **`add` overwrites a malformed database and loses its contents.** `Todoer.add()` only checks for `DB_READ_ERROR` (`rptodo.py:30`). On `JSON_ERROR` it appends to the empty list and writes it back, which replaces whatever was in the file. To trigger: truncate a database that holds several to-dos (for example, drop the final `]`), then run `rptodo add foo`. The file then holds only `foo.`. `tests/test_rptodo.py::test_add_wrong_json_format` asserts this behavior: an empty file returns `SUCCESS` and ends up with one item.
- **`list` reports an unreadable or malformed database as empty.** `Todoer.get_todo_list()` (`rptodo.py:36-39`) drops `read.error`. With a malformed database, `rptodo list` prints "There are no tasks in the to-do list yet" and exits 0, and `rptodo remove 1` (without `--force`) prints "Invalid TODO_ID".
- **ID 0 and negative IDs act on to-dos counted from the end of the list.** `todo_list[todo_id - 1]` (`rptodo.py:47`, `rptodo.py:60`, `cli.py:162`) turns ID 0 into index -1. `rptodo complete 0` marks the last to-do as done, and `rptodo remove 0 --force` deletes it, when both should fail with "to-do id error". Negative IDs (for example `rptodo complete -- -1`) also reach items counted from the end.
- **`init` fails when the parent config directory doesn't exist.** `CONFIG_DIR_PATH.mkdir(exist_ok=True)` (`config.py:26`) has no `parents=True`. On a system without `~/.config` (or wherever `XDG_CONFIG_HOME` points), `rptodo init` fails with `Creating config file failed with "config directory error"`.
- **A config write failure is reported as a database error.** When writing `config.ini` fails, `_create_database()` returns `DB_WRITE_ERROR` (`config.py:43`), so the user sees `Creating config file failed with "database write error"`. `FILE_ERROR` would match what actually failed. To trigger: make the config file read-only after `touch`, for example by running `chmod 444` on an existing `config.ini`, then run `rptodo init`.
- **A config file without a `[General]` section crashes every command.** `get_database_path()` (`database.py:19`) indexes `config_parser["General"]["database"]` without checking for it. If `config.ini` exists but is empty, which `init` leaves behind when the write in `config.py:40-41` fails after the `touch` on line 30, then `rptodo list` (and every command that calls `get_todoer()`) exits with a `KeyError` traceback instead of "Please, run rptodo init".

