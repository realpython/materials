# Code Smells

Check every module against both tables. Use the names from the Code Smell
and Refactoring columns exactly as written. The refactoring names come from
Martin Fowler's catalog at https://refactoring.com/catalog/.

## Smells in Human-Written Code

| Code Smell | Description | Refactoring |
| --- | --- | --- |
| Nested conditionals | Several levels of nested `if` statements | Replace with guard clauses |
| Long function | Validation, math, and formatting in one place | Extract function |
| Magic numbers | Unnamed literals inline | Replace with named constant |
| Dead code | Unreachable branches and functions that nothing calls | Remove dead code |
| Explanatory comments | A comment explaining the block below it | Extract function and rename |
| Repeated conditionals | The same `if` ... `elif` chain in several places | Replace with dispatch dictionary |
| Long parameter list | Six positional arguments | Introduce parameter object |
| Data clumps | The same values always passed together | Introduce parameter object |
| Duplicated code | The same logic in two places | Extract function |
| Primitive obsession | Strings and dictionaries where a type belongs | Replace primitive with object |
| Feature envy | Uses another object's data more than its own | Move function |
| Unclear naming | Names that don't say what they mean | Rename |
| Large class | One class with unrelated responsibilities | Extract class |

## Smells in Agent-Written Code

Agents tend to write these. Look for them in older agent-generated code.

| Code Smell | Description | Refactoring |
| --- | --- | --- |
| Copy-paste block | The same helper inlined three times | Extract function |
| Bloated procedure | One function that handles everything | Extract function |
| Basic-level verbosity | A loop where a comprehension belongs | Replace loop with pipeline |
| Speculative generality | A config flag that nothing ever sets | Remove dead code |
| Modular mirage | Many files with no shared cohesion | Move function |
| Error masking | A bare `except Exception: pass` | Replace with specific exception |
| Over-defensive guards | An `if x is not None` check before every use | Remove redundant guard |
