# Copilot Instructions for Tic-Tac-Toe

## Overview
This is a desktop Tic-Tac-Toe game built with Python and Tkinter. The application features a graphical 3x3 grid where two players take turns marking cells, with automatic win detection and game reset functionality.

## Running the Application

```bash
# Run the game
python main.py
```

No dependencies beyond Python's standard library (Tkinter is included).

## Architecture

The codebase separates concerns into two main classes:

### `TicTacToeGame` (Game Logic)
- **Responsibility**: Core game state and rules
- **Key attributes**:
  - `_current_moves`: 2D list of `Move` objects representing board state
  - `_winning_combos`: Pre-computed list of all winning position combinations (rows, columns, diagonals)
  - `current_player`: Tracks whose turn it is using a cycle iterator
  - `_has_winner`: Boolean flag for win state
- **Key methods**:
  - `is_valid_move()`: Validates move legality
  - `process_move()`: Updates board and checks win condition
  - `is_tied()`: Detects draw state
  - `reset_game()`: Clears board for replaying

### `TicTacToeBoard` (UI Layer)
- **Responsibility**: Tkinter GUI and user interaction
- **Key attributes**:
  - `_cells`: Dictionary mapping button widgets to their (row, col) coordinates
  - `_game`: Reference to the game logic instance
- **Key methods**:
  - `play()`: Event handler for button clicks
  - `_update_button()`: Updates cell display with player label and color
  - `_highlight_cells()`: Highlights winning combo cells in red
  - `reset_board()`: Clears UI state

### Data Models
- `Player(label, color)`: NamedTuple representing a player
- `Move(row, col, label)`: NamedTuple representing a board move with optional label

## Key Conventions

### Move Validation
The game validates moves in two ways:
1. `is_valid_move()` checks if move is legal (cell empty + no winner yet)
2. The `play()` handler only updates UI if validation passes

### Win Detection
Winning combos are pre-computed once at initialization and reused. A win is detected when all cells in a combo have the same non-empty label.

### Player Cycling
Players are cycled using `itertools.cycle()`. Call `toggle_player()` after each valid move to advance to the next player.

### Board Resetting
The `reset_game()` method creates fresh `Move` objects (preserving structure) rather than replacing the entire `_current_moves` list. The UI's `reset_board()` must also be called to clear button states.

## Type Hints
The codebase uses Python type hints throughout. Maintain this pattern when adding methods or modifying signatures.

## Game State Flow
1. Player clicks button → `play()` event handler fires
2. `is_valid_move()` checks legality
3. `process_move()` updates board and checks for win
4. `_update_button()` reflects move in UI
5. Either game ends (win/tie) or `toggle_player()` is called to switch turns
